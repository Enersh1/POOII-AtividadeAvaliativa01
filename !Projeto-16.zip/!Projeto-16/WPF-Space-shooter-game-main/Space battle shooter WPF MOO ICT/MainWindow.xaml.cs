﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Space_battle_shooter_WPF_MOO_ICT
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer gameTimer = new DispatcherTimer();
        bool moveLeft, moveRight;
        List<Rectangle> itemRemover = new List<Rectangle>();

        Random rand = new Random();

        int enemySpriteCounter = 0;
        int enemyCounter = 100;
        int playerSpeed = 10;
        int limit = 50;
        int score = 0;
        int damage = 0;
        int enemySpeed = 10;

        Rect playerHitBox;

        // ===================== NOVO: Sistema de Vidas =====================
        int lives = 3;                 // quantidade de vidas do jogador
        TextBlock livesText;           // label criada em código (não existe na XAML original)
        // ====================================================================

        // ================ NOVO: Pausa e Menu Inicial =======================
        bool gameStarted = false;      // controla se o jogo já começou (tela de menu)
        bool isPaused = false;         // controla se o jogo está pausado
        TextBlock menuOverlay;         // texto da tela inicial
        TextBlock pauseOverlay;        // texto exibido quando pausado
        // ====================================================================

        public MainWindow()
        {
            InitializeComponent();

            gameTimer.Interval = TimeSpan.FromMilliseconds(20);
            gameTimer.Tick += GameLoop;
            gameTimer.Start(); // INTEGRAÇÃO: mantido igual ao original — o timer roda,
                               // mas o GameLoop agora ignora a lógica de jogo até gameStarted = true (ver GameLoop)

            MyCanvas.Focus();

            ImageBrush bg = new ImageBrush();

            bg.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/purple.png"));
            bg.TileMode = TileMode.Tile;
            bg.Viewport = new Rect(0, 0, 0.15, 0.15);
            bg.ViewportUnits = BrushMappingMode.RelativeToBoundingBox;
            MyCanvas.Background = bg;

            ImageBrush playerImage = new ImageBrush();
            playerImage.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/player.png"));
            player.Fill = playerImage;

            // ===================== NOVO: Sistema de Vidas =====================
            // Criamos o label de vidas em código, no mesmo estilo em que o
            // MakeEnemies() cria Rectangles e os adiciona ao MyCanvas.
            livesText = new TextBlock
            {
                Text = "Vidas: " + lives,
                Foreground = Brushes.White,
                FontSize = 16,
                FontWeight = FontWeights.Bold
            };
            Canvas.SetLeft(livesText, 10);
            Canvas.SetTop(livesText, 40); // logo abaixo de onde ficam scoreText/damageText
            MyCanvas.Children.Add(livesText);
            // ====================================================================

            // ================ NOVO: Pausa e Menu Inicial =======================
            menuOverlay = new TextBlock
            {
                Text = "SPACE BATTLE SHOOTER\n\nPressione ENTER para começar\nSetas = mover | Espaço = atirar | P = pausar",
                Foreground = Brushes.White,
                FontSize = 22,
                FontWeight = FontWeights.Bold,
                TextAlignment = TextAlignment.Center,
                Background = new SolidColorBrush(Color.FromArgb(180, 0, 0, 0))
            };
            Canvas.SetLeft(menuOverlay, 40);
            Canvas.SetTop(menuOverlay, 250);
            MyCanvas.Children.Add(menuOverlay);

            pauseOverlay = new TextBlock
            {
                Text = "PAUSADO\nPressione P para continuar",
                Foreground = Brushes.Yellow,
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                TextAlignment = TextAlignment.Center,
                Background = new SolidColorBrush(Color.FromArgb(180, 0, 0, 0)),
                Visibility = Visibility.Collapsed // só aparece quando isPaused = true
            };
            Canvas.SetLeft(pauseOverlay, 90);
            Canvas.SetTop(pauseOverlay, 300);
            MyCanvas.Children.Add(pauseOverlay);
            // ====================================================================
        }

        private void GameLoop(object sender, EventArgs e)
        {
            // ================ INTEGRAÇÃO: Pausa e Menu Inicial =================
            // Enquanto o menu inicial não foi dispensado (Enter) ou o jogo está
            // pausado (P), a lógica original do professor abaixo nem é executada.
            if (!gameStarted || isPaused)
            {
                return;
            }
            // ====================================================================

            playerHitBox = new Rect(Canvas.GetLeft(player), Canvas.GetTop(player), player.Width, player.Height);

            enemyCounter -= 1;

            scoreText.Content = "Score: " + score;
            damageText.Content = "Damage " + damage;

            if (enemyCounter < 0)
            {
                MakeEnemies();
                enemyCounter = limit;
            }

            if (moveLeft == true && Canvas.GetLeft(player) > 0)
            {
                Canvas.SetLeft(player, Canvas.GetLeft(player) - playerSpeed);
            }
            if (moveRight == true && Canvas.GetLeft(player) + 90 < Application.Current.MainWindow.Width)
            {
                Canvas.SetLeft(player, Canvas.GetLeft(player) + playerSpeed);
            }


            foreach (var x in MyCanvas.Children.OfType<Rectangle>())
            {
                if (x is Rectangle && (string)x.Tag == "bullet")
                {
                    Canvas.SetTop(x, Canvas.GetTop(x) - 20);

                    Rect bulletHitBox = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                    if (Canvas.GetTop(x) < 10)
                    {
                        itemRemover.Add(x);
                    }

                    foreach (var y in MyCanvas.Children.OfType<Rectangle>())
                    {
                        if (y is Rectangle && (string)y.Tag == "enemy")
                        {
                            Rect enemyHit = new Rect(Canvas.GetLeft(y), Canvas.GetTop(y), y.Width, y.Height);

                            if (bulletHitBox.IntersectsWith(enemyHit))
                            {
                                itemRemover.Add(x);
                                itemRemover.Add(y);
                                score++;
                            }
                        }
                    }

                }

                if (x is Rectangle && (string)x.Tag == "enemy")
                {
                    Canvas.SetTop(x, Canvas.GetTop(x) + enemySpeed);

                    if (Canvas.GetTop(x) > 750)
                    {
                        itemRemover.Add(x);
                        damage += 10;
                    }

                    Rect enemyHitBox = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                    if (playerHitBox.IntersectsWith(enemyHitBox))
                    {
                        itemRemover.Add(x);
                        damage += 5;
                    }

                }
            }

            foreach (Rectangle i in itemRemover)
            {
                MyCanvas.Children.Remove(i);
            }


            if (score > 5)
            {
                limit = 20;
                enemySpeed = 15;
            }

            // ================ MODIFICADO: Sistema de Vidas =====================
            // Trecho original apenas encerrava o jogo direto quando damage > 99.
            // Agora, isso só acontece quando as vidas também chegam a zero;
            // caso contrário, perde-se uma vida e o dano é zerado para continuar.
            if (damage > 99)
            {
                lives -= 1;                          // NOVO: consome uma vida
                livesText.Text = "Vidas: " + lives;   // NOVO: atualiza o label

                if (lives > 0)
                {
                    // NOVO: ainda restam vidas — reseta o dano e avisa o jogador,
                    // sem interromper a DispatcherTimer nem reiniciar o processo.
                    damage = 0;
                    damageText.Content = "Damage 0";
                    MessageBox.Show("Nave atingida! Vidas restantes: " + lives, "MOO Says: ");
                }
                else
                {
                    gameTimer.Stop();
                    damageText.Content = "Damage: 100";
                    damageText.Foreground = Brushes.Red;
                    MessageBox.Show("Captain You have destroyed " + score + " Alien Ships" + Environment.NewLine + "Press Ok to Play Again", "MOO Says: ");

                    System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);
                    Application.Current.Shutdown();
                }
            }
            // ====================================================================
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            // ================ INTEGRAÇÃO: Pausa e Menu Inicial =================
            if (!gameStarted || isPaused)
            {
                return; // ignora movimento enquanto o menu/pausa estiverem na tela
            }
            // ====================================================================

            if (e.Key == Key.Left)
            {
                moveLeft = true;
            }
            if (e.Key == Key.Right)
            {
                moveRight = true;
            }
        }

        private void OnKeyUp(object sender, KeyEventArgs e)
        {
            // ================ NOVO: Menu Inicial (tecla Enter) =================
            if (!gameStarted)
            {
                if (e.Key == Key.Enter)
                {
                    gameStarted = true;
                    menuOverlay.Visibility = Visibility.Collapsed;
                }
                return; // enquanto o menu estiver ativo, nenhuma outra tecla faz efeito
            }
            // ====================================================================

            // ===================== NOVO: Pausa (tecla P) ========================
            if (e.Key == Key.P)
            {
                isPaused = !isPaused;
                pauseOverlay.Visibility = isPaused ? Visibility.Visible : Visibility.Collapsed;
                return; // não deixa a tecla P cair na lógica original abaixo
            }

            if (isPaused)
            {
                return; // bloqueia disparo/movimento enquanto pausado
            }
            // ====================================================================

            if (e.Key == Key.Left)
            {
                moveLeft = false;
            }
            if (e.Key == Key.Right)
            {
                moveRight = false;
            }

            if (e.Key == Key.Space)
            {
                Rectangle newBullet = new Rectangle
                {
                    Tag = "bullet",
                    Height = 20,
                    Width = 5,
                    Fill = Brushes.White,
                    Stroke = Brushes.Red

                };

                Canvas.SetLeft(newBullet, Canvas.GetLeft(player) + player.Width / 2);
                Canvas.SetTop(newBullet, Canvas.GetTop(player) - newBullet.Height);

                MyCanvas.Children.Add(newBullet);

            }
        }

        private void MakeEnemies()
        {
            ImageBrush enemySprite = new ImageBrush();

            enemySpriteCounter = rand.Next(1, 5);

            switch (enemySpriteCounter)
            {
                case 1:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/1.png"));
                    break;
                case 2:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/2.png"));
                    break;
                case 3:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/3.png"));
                    break;
                case 4:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/4.png"));
                    break;
                case 5:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/images/5.png"));
                    break;
            }

            Rectangle newEnemy = new Rectangle
            {
                Tag = "enemy",
                Height = 50,
                Width = 56,
                Fill = enemySprite
            };

            Canvas.SetTop(newEnemy, -100);
            Canvas.SetLeft(newEnemy, rand.Next(30, 430));
            MyCanvas.Children.Add(newEnemy);

        }
    }
}