```C#
public partial class Form1 : Form
    {
        Image player;
        Image background;
        Image drum;
        Image fireball;

        int playerX = 0;
        int playerY = 300;

        int drumX = 450;
        int drumY = 335;

        int fireballX;
        int fireballY;

        int drumMoveTime = 0;
        int actionStrength = 0;
        int endFrame = 0;
        int backgroundPosition = 0;
        int totalFrame = 0;
        int bg_number = 0;

        float num;

        bool goLeft, goRight;
        bool directionPressed;
        bool playingAction;
        bool shotFireBall;
        // ...
    }
```

**Class player**
Image player;
int playerX = 0;
int playerY = 300;

**Class Drum**
Image drum;
int drumX = 450;
int drumY = 335;
int drumMoveTime = 0;

**Class fireball**
Image fireball;
int fireballX;
int fireballY;
bool shotFireBall;

---

```C#
        public Form1()
        {
            InitializeComponent();
            SetUpForm();
        }

```

```C#
private void KeyIsDown(object sender, KeyEventArgs e){...}

private void KeyIsUp(object sender, KeyEventArgs e){...}

private void FormPaintEvent(object sender, PaintEventArgs e){...}

private void GameTimerEvent(object sender, EventArgs e){...}

private void SetUpForm(){...}

private void SetUpAnimation(){...}

private void OnFrameChangedHandler(object? sender, EventArgs e){...}

private void MovePlayerandBackground(){...}

private void MovePlayerAnimation(string direction){...}

private void ResetPlayer(){...}

private void SetPlayerAction(string animation, int strength){...}

private void ShootFireball(){...}

private void CheckPunchHit(){...}

private void CheckFireballHit(){...}

private bool DetectCollision(int object1X, int object1Y, int object1Width, int object1Height, int object2X, int object2Y, int object2Width, int object2Height){...}

```