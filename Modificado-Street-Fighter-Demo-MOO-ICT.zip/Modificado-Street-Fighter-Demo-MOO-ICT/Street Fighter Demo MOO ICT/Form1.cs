using System.Drawing.Imaging;


namespace Street_Fighter_Demo_MOO_ICT
{
    public partial class Form1 : Form
    {
        Image player;
        Image background;
        Image drum;
        Image fireball;

        int playerX = 0;
        int playerY = 300;

        int drumX = 450;
        int drumY = 335;

        int fireballX;
        int fireballY;

        int drumMoveTime = 0;
        int actionStrength = 0;
        int endFrame = 0;
        int backgroundPosition = 0;
        int totalFrame = 0;
        int bg_number = 0;

        float num;

        bool goLeft, goRight;
        bool directionPressed;
        bool playingAction;
        bool shotFireBall;

        bool facingRight = true;
        int fireballDirection = 1;

        List<string> background_images = new List<string>();


        public Form1()
        {
            InitializeComponent();
            SetUpForm();
        }

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left && !directionPressed)
            {
                MovePlayerAnimation("left");
            }
            if (e.KeyCode == Keys.Right && !directionPressed)
            {
                MovePlayerAnimation("right");
            }
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.X)
            {
                if (bg_number < background_images.Count - 1)
                {
                    bg_number++;
                }
                else
                {
                    bg_number = 0;
                }
                background = Image.FromFile(background_images[bg_number]);
                backgroundPosition = 0;
                drumMoveTime = 0;
                drumX = 300;
            }

            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.Left)
            {
                goLeft = false;
                goRight = false;
                directionPressed = false;
                ResetPlayer();
            }

            if (e.KeyCode == Keys.A && !playingAction && !goLeft && !goRight)
            {
                SetPlayerAction("punch2.gif", 2);
            }
            if (e.KeyCode == Keys.S && !playingAction && !goLeft && !goRight)
            {
                SetPlayerAction("punch1.gif", 5);
            }
            if (e.KeyCode == Keys.D && !playingAction && !goLeft && !goRight && !shotFireBall)
            {
                SetPlayerAction("fireball.gif", 30);
            }


        }

        private void FormPaintEvent(object sender, PaintEventArgs e)
        { // --- MODIFICADO : CORREÇÃO DE MOVIMENTO ---
            e.Graphics.DrawImage(background, new Point(backgroundPosition, 0));

            // --- RENDERIZAR (DESENHAR) O PLAYER COM BASE NA DIREÇÃO ---
            if (facingRight)
            {
                // --- DESENHAR PLAYER NORMAL ---
                e.Graphics.DrawImage(player, new Point(playerX, playerY));
            }
            else
            {
                // --- DESENHAR PLAYER ESPELHADO ---
                // posição X + largura do player = largura do player
                // largura do player * -1 = largura do player negativa
                // altura do player = altura do player
                // posição Y = altura do player
                e.Graphics.DrawImage(player, new Rectangle(playerX + player.Width, playerY, -player.Width, player.Height));
            }

            // e.Graphics.DrawImage(player, new Point(playerX, playerY));
            
            e.Graphics.DrawImage(drum, new Point(drumX, drumY));

            if (shotFireBall)
            {
                if (fireballDirection == 1)
                {
                    // --- DESENHAR FIREBALL NORMAL ---
                    e.Graphics.DrawImage(fireball, new Point(fireballX, fireballY));
                }
                else
                {
                    // --- DESENHAR FIREBALL ESPELHADA ---
                    e.Graphics.DrawImage(fireball, fireballX + fireball.Width, fireballY, - fireball.Width, fireball.Height);
                }
            }

        }

        private void GameTimerEvent(object sender, EventArgs e)
        { // --- MODIFICADO : CORREÇÃO DE MOVIMENTO (ATAQUES) ---
            // determinar a direcao baseado no centro do player e do drum
            int playerCenterX = playerX + player.Width / 2;
            int drumCenterX = drumX + drum.Width / 2;

            facingRight = playerCenterX <= drumCenterX; // verdadeiro se o player estiver à esquerda do drum, falso caso contrário

            this.Invalidate();
            ImageAnimator.UpdateFrames();
            MovePlayerandBackground();
            CheckPunchHit();

            if (playingAction)
            {
                if (num < totalFrame)
                {
                    num += 0.5f;
                }
            }
            if (num == totalFrame)
            {
                ResetPlayer();
            }

            // fireball instructions for the time. 

            if (shotFireBall)
            {
                // movimenta o hadouken de acordo com a direção do personagem
                fireballX += 10 * fireballDirection;
                CheckFireballHit();
            }
            // Se Hadouken sair da tela pelas laterais -> Desaparece
            if (fireballX > this.ClientSize.Width || fireballX + fireball.Width < 0)
            {
                shotFireBall = false;
            }

            if (!shotFireBall && num > endFrame && drumMoveTime == 0 && actionStrength == 30)
            {
                ShootFireball();
            }
            // Ajustando movimento do Drum ao levar dano
            if (drumMoveTime > 0)
            { // Quando Drum toma hit, empurrar p/ direção oposta ao golpe
                drumMoveTime--;
                if (facingRight){
                    drumX += 10;
                }
                else {
                    drumX -= 10;
                }
                
                //drumX += 10;
                drum = Image.FromFile("hitdrum.png");
            }
            else
            {
                drum = Image.FromFile("drum.png");
                drumMoveTime = 0;
            }
            // Resetar Drum se sair pelas bordas laterais
            if (drumX > this.ClientSize.Width || drumX + drum.Width < 0)
            {
                drumMoveTime = 0;
                drumX = 300;
            }


        }

        private void SetUpForm()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);

            background_images = Directory.GetFiles("background", "*.jpg").ToList();
            background = Image.FromFile(background_images[bg_number]);
            player = Image.FromFile("standing.gif");
            drum = Image.FromFile("drum.png");
            SetUpAnimation();

        }

        private void SetUpAnimation()
        {
            ImageAnimator.Animate(player, this.OnFrameChangedHandler);
            FrameDimension dimentions = new FrameDimension(player.FrameDimensionsList[0]);
            totalFrame = player.GetFrameCount(dimentions);
            endFrame = totalFrame - 3;
        }

        private void OnFrameChangedHandler(object? sender, EventArgs e)
        {
            this.Invalidate();
        }

        private void MovePlayerandBackground()
        { // QUANDO PLAYER VAI PARA BORDA -> Mover player & Background & Drum?
            if (goLeft)
            {
                if (playerX > 0)
                {
                    playerX -= 6;
                }

                if (backgroundPosition < 0 && playerX < 100)
                {
                    backgroundPosition += 5;
                    drumX += 5;
                }

            }
            if (goRight)
            {
                if (playerX + player.Width < this.ClientSize.Width)
                {
                    playerX += 6;
                }

                if (backgroundPosition + background.Width > this.ClientSize.Width + 5 && playerX > 650)
                {
                    backgroundPosition -= 5;
                    drumX -= 5;
                }

            }
        }

        private void MovePlayerAnimation(string direction)
        { // --- MODIFICADO : CORREÇÃO DE MOVIMENTO ---
            if (direction == "left")
            { // Se for para a ESQUERDA
                goLeft = true;
                // se virado p/ direita --> esquerda == backwards (virado para trás)
                // se virado p/ esquerda --> esquerda == forwards (virado para frente)
                player = facingRight ? Image.FromFile("backwards.gif") : Image.FromFile("forwards.gif");
                
                // se facingRight && direction == left --> backwards (vai para tras)
                // se !facingRight && direction == left --> forwards (vai para frente)
            }
            if (direction == "right")
            { // Se for para a DIREITA
                goRight = true;
                // se virado p/ direita --> direita == forwards (virado para frente)
                // se virado p/ esquerda --> direita == backwards (virado para trás)
                player = facingRight ? Image.FromFile("forwards.gif") : Image.FromFile("backwards.gif");
            }

            directionPressed = true;
            playingAction = false;
            SetUpAnimation();
        }

        private void ResetPlayer()
        {
            player = Image.FromFile("standing.gif");
            SetUpAnimation();
            num = 0;
            playingAction = false;


        }

        private void SetPlayerAction(string animation, int strength)
        {
            player = Image.FromFile(animation);
            actionStrength = strength;
            SetUpAnimation();
            playingAction = true;
        }

        private void ShootFireball()
        { // --- MODIFICADO : CORREÇÃO DE POSIÇÃO E DIREÇÃO --- 
            fireball = Image.FromFile("FireBallFinal.gif");
            ImageAnimator.Animate(fireball, this.OnFrameChangedHandler);
            
            //fireballX = playerX + player.Width - 50;
            //fireballY = playerY - 33;

            // fireballDirection = facingRight ? 1 : -1;
            // ao invés de fazer 2 verificações, juntei ambas em uma

            if (facingRight){
                // Se facingRight == True
                fireballDirection = 1; // direção == 1 (direita)
                fireballX = playerX + player.Width - 50; // posição == jogador + largura do jogador - 50
            }
            else{
                // Se facingRight == False
                fireballDirection = -1; // direção == -1 (esquerda)
                fireballX = playerX - fireball.Width + 50; // posição == jogador - largura do jogador + 50
            }
            fireballY = playerY - 33; // posição == jogador - 33 (pos. fixa)
            shotFireBall = true;
        }

        private void CheckPunchHit()
        {
            bool collision = DetectCollision(playerX, playerY, player.Width, player.Height, drumX, drumY, drum.Width, drum.Height);

            if (collision && playingAction && num > endFrame)
            {
                drumMoveTime = actionStrength;
            }
        }

        private void CheckFireballHit()
        {
            bool collision = DetectCollision(fireballX, fireballY, fireball.Width, fireball.Height, drumX, drumY, drum.Width, drum.Height);

            if (collision)
            {
                drumMoveTime = actionStrength;
                shotFireBall = false;
            }

        }

        private bool DetectCollision(int object1X, int object1Y, int object1Width, int object1Height, int object2X, int object2Y, int object2Width, int object2Height)
        {
            if (object1X + object1Width <= object2X || object1X >= object2X + object2Width || object1Y + object1Height <= object2Y || object1Y >= object2Y + object2Height)
            {
                return false;
            }
            else
            {
                return true;
            }
        }


    }
}